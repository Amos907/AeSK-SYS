# core/user/__init__.py
default_app_config = 'core.user.apps.UserConfig'